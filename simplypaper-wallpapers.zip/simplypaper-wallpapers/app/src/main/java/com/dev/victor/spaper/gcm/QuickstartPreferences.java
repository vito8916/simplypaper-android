package com.dev.victor.spaper.gcm;

/**
 * Created by vic_a on 22/5/2016.
 */
public class QuickstartPreferences {

    public static final String SENT_TOKEN_TO_SERVER = "sentTokenToServer";
    public static final String REGISTRATION_COMPLETE = "registrationComplete";

}

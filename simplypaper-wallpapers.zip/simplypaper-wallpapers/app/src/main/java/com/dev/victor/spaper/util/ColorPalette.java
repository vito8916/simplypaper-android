package com.dev.victor.spaper.util;

/**
 * Created by Victor on 07/10/2015.
 */
public class ColorPalette {
    private int vibrant;
    private int lightVibrant;
    private int darkVibrant;
    private int muted;

    public int getVibrant() {
        return vibrant;
    }

    public void setVibrant(int vibrant) {
        this.vibrant = vibrant;
    }

    public int getLightVibrant() {
        return lightVibrant;
    }

    public void setLightVibrant(int lightVibrant) {
        this.lightVibrant = lightVibrant;
    }

    public int getDarkVibrant() {
        return darkVibrant;
    }

    public void setDarkVibrant(int darkVibrant) {
        this.darkVibrant = darkVibrant;
    }

    public int getMuted() {
        return muted;
    }

    public void setMuted(int muted) {
        this.muted = muted;
    }
}

package com.dev.victor.spaper.util;

/**
 * Created by Victor on 28/09/2015.
 */
public class FeedItemNuevas {

    private String idPhoto;
    private String title;
    private String urlimg;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUrlimg() {
        return urlimg;
    }

    public void setUrlimg(String urlimg) {
        this.urlimg = urlimg;
    }

    public String getIdPhoto() {
        return idPhoto;
    }

    public void setIdPhoto(String idPhoto) {
        this.idPhoto = idPhoto;
    }
}
